/*
 * misc.c
 *
 *  Created on: 10 mars 2016
 *      Author: faitaoudia
 */

#include <msp430.h>
#include <misc.h>
#include <stdint.h>

// -----------------------------------------------------------------------
// Implementation of some useful functions
// -----------------------------------------------------------------------
/*
 * C++ version 0.4 char* style "itoa":
 * Written by Luk�s Chmela
 * Released under GPLv3.
 *
 * Convert a int to a string.
 */
char* itoa(int value, char* result, int base)
{

        // check that the base if valid
        if (base < 2 || base > 36) { *result = '\0'; return result; }
        char* ptr = result, *ptr1 = result, tmp_char;
        int tmp_value, init_value = value;

        do {
                tmp_value = value;
                value /= base;
                *ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
        } while ( value );

        if(init_value<10) {
			*ptr++ = '0';
		}

        // Apply negative sign
        if (tmp_value < 0) *ptr++ = '-';
        *ptr-- = '\0';
        while(ptr1 < ptr) {
                tmp_char = *ptr;
                *ptr--= *ptr1;
                *ptr1++ = tmp_char;
        }

        return result;
}

// --------------------------------------------------------------------------
// LED manipulations
// The used LED is the LED2 (P1.0)
// --------------------------------------------------------------------------
void led_init(void)
{
	P4DIR |= BIT6;
	P4OUT &= ~BIT6;
}

void led_on(void)
{
	P4OUT |= BIT6;
}

void led_off(void)
{
	P4OUT &= ~BIT6;
}

void led_blink(void)
{
	led_on();
	__delay_cycles(500000); // 0.5 s delay
	led_off();
}

// -----------------------------------------------------------------------------
// Button SW1
// When it is pressed, the LPM3 mode is left.
// -----------------------------------------------------------------------------
// Event id associated with the button
static uint16_t _sw1_event;

void sw1_init(event_handler_t sw1_handler)
{
	// SW1 is on P4.5
	P4DIR &= ~BIT5;	// Input
	P4OUT |= BIT5;	// Pull up
	P4REN |= BIT5;	// Pull-up enabled
	P4IFG &= ~BIT5;	// Clear interrupts
	P4IES |= BIT5;	// On a high to low transition...
	P4IE |= BIT5;	// ...generate an interrupt

	_sw1_event = event_add(sw1_handler);
}

#define SW1	(!(P4IN & BIT5))

#pragma vector=PORT4_VECTOR
__interrupt void sw1_interrupt_handler(void)
{
	if (P4IFG & BIT5)
	{
		// Wait for the button to be released
		while (SW1);

		// Reset the interrupt flag
		P4IFG &= ~BIT5;

		// Signal the event associated with the button
		EVENT_SIGNAL_ISR(_sw1_event);
	}
}
